# Assignment 1 - Images

This is an empty markdown file.  We have used this in the repo to ensure the folder structure is preserved.
